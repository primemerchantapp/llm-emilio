export type TAttachment = {
  file?: File;
  base64?: string;
};
