export type TPrompt = {
  id: string;
  name: string;
  content: string;
};
