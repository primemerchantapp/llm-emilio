export type TConstructPrompt = {
  context?: string;
  image?: string;
  memories: string[];
  hasMessages: boolean;
  systemPrompt: string;
  formatInstructions?: boolean;
};
