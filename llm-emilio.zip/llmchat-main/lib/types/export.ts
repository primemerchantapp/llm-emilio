import { dataValidator } from "@/libs/utils/validator";
import { z } from "zod";

export type ExportData = z.infer<typeof dataValidator>;
