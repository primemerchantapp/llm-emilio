import Plausible from "plausible-tracker";

const plausible = Plausible({
  domain: "llmchat.co",
});

export default plausible;
