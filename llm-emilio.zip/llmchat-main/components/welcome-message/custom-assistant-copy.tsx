export const CustomAssistantCopy = () => {
  return (
    <>
      Craft your own custom assistant by providing specialized instructions and
      knowledge tailored to your unique needs.
    </>
  );
};
