export const BetaTag = () => {
  return (
    <div className="rounded-full bg-zinc-500/20 px-1.5 py-0.5 text-[0.6rem] font-medium tracking-wide text-zinc-800 dark:text-zinc-200">
      Beta
    </div>
  );
};
