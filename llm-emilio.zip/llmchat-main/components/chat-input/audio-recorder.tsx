
import { useChatContext } from "@/lib/context";
import { useRecordVoice } from "@/lib/hooks";
import { formatTickerTime } from "@/lib/utils/utils";
import {
  AudioVisualizer,
  Button,
  Dialog,
  DialogContent,
  Flex,
  LinearSpinner,
  Tooltip,
  Type,
} from "@/ui";
import { Check, Circle, X } from "lucide-react";
import { FC, useEffect, useState } from "react";

export type TAudioRecorder = {
  sendMessage: (message: string) => void;
};

export const AudioRecorder: FC<TAudioRecorder> = ({ sendMessage }) => {
  const { store } = useChatContext();
  const session = store((state) => state.session);
  const editor = store((state) => state.editor);

  const {
    stream,
    elapsedTime,
    stopRecording,
    recording,
    transcribing,
    text,
    cancelRecording,
    startVoiceRecording,
  } = useRecordVoice();

  const [portalElement, setPortalElement] = useState<HTMLElement | null>(null);

  useEffect(() => {
    setPortalElement(document.body);
  }, []);

  useEffect(() => {
    if (text && session) {
      editor?.commands.clearContent();
      editor?.commands.setContent(text);
      sendMessage(text);
    }
  }, [text]);

  useEffect(() => {
    if (transcribing) {
      editor?.setEditable(false);
    } else {
      editor?.setEditable(true);
    }
  }, [transcribing]);

  return (
    <Flex>
      <Tooltip content="Record">
        <Button
          size="icon-sm"
          variant="ghost"
          onClick={() => {
            if (!recording) {
              startVoiceRecording();
            } else {
              stopRecording();
            }
          }}
        >
          <Circle size={16} strokeWidth="2" />
        </Button>
      </Tooltip>
      {transcribing && (
        <Flex
          items="center"
          justify="center"
          gap="sm"
          className="absolute inset-0 z-[50] h-full w-full bg-white/50 backdrop-blur-sm dark:bg-zinc-800/50"
        >
          <LinearSpinner /> <Type textColor="secondary">Transcribing ...</Type>
        </Flex>
      )}

      <Dialog open={recording} onClose={cancelRecording}>
        <DialogContent className="w-full max-w-md">
          <Flex direction="column" gap="md" className="w-full p-6">
            <Type size="sm" textColor="secondary">
              Recording... {formatTickerTime(elapsedTime)}
            </Type>

            <AudioVisualizer stream={stream} />

            <Flex gap="sm" className="w-full p-6" justify="center">
              <Button
                variant="secondary"
                rounded="full"
                size="lg"
                onClick={() => {
                  cancelRecording();
                }}
                className="group"
              >
                <X size={16} strokeWidth="2" />
                Cancel
              </Button>
              <Button
                rounded="full"
                size="lg"
                onClick={() => {
                  stopRecording();
                }}
                className="group"
              >
                <Check size={16} strokeWidth="2" />
                Done
              </Button>
            </Flex>
          </Flex>
        </DialogContent>
      </Dialog>
    </Flex>
  );
};
