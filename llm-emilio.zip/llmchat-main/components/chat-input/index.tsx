
import { examplePrompts } from "@/config/example-prompts";
import {
  useChatContext,
  usePreferenceContext,
  useSessions,
} from "@/lib/context";
import {
  useAssistantUtils,
  useChatEditor,
  useImageAttachment,
  useLLMRunner,
} from "@/lib/hooks";
import { slideUpVariant } from "@/lib/utils/animations";
import { cn } from "@/lib/utils/clsx";
import { Badge, Button, Flex, Type } from "@/ui";
import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { ChangeLogs } from "../changelogs";
import { CustomAssistantAvatar } from "../custom-assistant-avatar";
import { FullPageLoader } from "../full-page-loader";
import { ApiKeyStatus } from "./api-key-status";
import { ChatActions } from "./chat-actions";
import { ChatEditor } from "./chat-editor";
import { ChatFooter } from "./chat-footer";
import { ImageAttachment } from "./image-attachment";
import { ImageDropzoneRoot } from "./image-dropzone-root";

// New imports to handle file uploads
import { FileUpload } from "@mui/icons-material";
import { useFileAttachment } from "@/lib/hooks/useFileAttachment";
import { processRADData } from "@/lib/utils/radDataProcessor";

export const ChatInput = () => {
  const { store } = useChatContext();
  const session = store((state) => state.session);
  const editor = useChatEditor();
  const { attachFile, handleFileUpload } = useFileAttachment();

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (file) {
      await handleFileUpload(file);
      // Process the uploaded file as RAD data
      processRADData(file);
    }
  };

  return (
    <Flex direction="row" align="center" className="chat-input-container">
      {/* File Attachment Button */}
      <Button variant="ghost" size="icon-sm" component="label">
        <FileUpload />
        <input
          type="file"
          accept=".pdf,.txt,.doc,.docx"
          hidden
          onChange={handleFileChange}
        />
      </Button>

      {/* Chat input box */}
      <ChatEditor />

      {/* File processing for RAG */}
      <ApiKeyStatus />
    </Flex>
  );
};

// Helper function for processing RAG data
export const processRADData = async (file) => {
  const reader = new FileReader();

  reader.onload = function(e) {
    const fileContent = e.target.result;
    // Extract content and store as RAG data
    console.log("File content to be processed as RAD:", fileContent);
    // Here you can implement logic to extract the text and store it as RAG data
  };

  if (file.type === "application/pdf") {
    // For PDF, you might need to use a PDF parsing library
    // Example: pdf-lib or any other library to extract text from PDF
  } else {
    reader.readAsText(file);
  }
};

export default ChatInput;
