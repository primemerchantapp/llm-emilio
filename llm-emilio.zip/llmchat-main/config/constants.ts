export const constants = {
  avatarColors: ["#063940", "#195e63", "#3e838c", "#8ebdb6", "#ece1c3"],
};
